<?php

use Illuminate\Support\Facades\Route;

Route::get('/home.html', function () {
    return view('home');
});

Route::get('/cart.html', function () {
    return view('cart');
});

Route::get('/shop.html', function () {
    return view('shop');
});

Route::get('/checkout.html', function () {
    return view('checkout');
});

Route::get('/product-details.html', function () {
    return view('product-details');
});

Route::get('/wishlist.html', function () {
    return view('wishlist');
});

Route::get('/login.html', function () {
    return view('login');
});

Route::get('/register.html', function () {
    return view('register');
});

Route::get('/admin.html', function () {
    return view('admin');
});

