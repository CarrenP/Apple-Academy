create database YOUNIQUE_data;
use YOUNIQUE_data;


create table customer(idcust varchar(10) , nama_cust varchar (50), alamat_cust varchar (50), nohp_cust varchar (20),
kota_cust varchar(25), kelurahan_cust varchar (25), kodepost_cust int(20)
);

INSERT INTO customer (idcust, nama_cust, alamat_cust, nohp_cust, kota_cust, kelurahan_cust, kodepost_cust)
VALUES 
('CU0001', 'Bob Brown', 'Jl. Gajah Mada No. 101', 081234567893, 'Medan', 'Petisah', 34567),
('CU0002', 'Emily Wang', 'Jl. Pemuda No. 202', 081234567894, 'Semarang', 'Tembalang', 45678),
('CU0003', 'Michael Chen', 'Jl. Malioboro No. 303', 081234567895, 'Yogyakarta', 'Sinduadi', 56789),
('CU0004', 'Siti Nur', 'Jl. Ijen No. 404', 081234567896, 'Malang', 'Blimbing', 67891),
('CU0005', 'Ahmad Syafiq', 'Jl. Sudirman No. 505', 081234567897, 'Palembang', 'Ilir Timur I', 78901),
('CU0006', 'Linda Wijaya', 'Jl. Raya Bogor No. 606', 081234567898, 'Jakarta', 'Cipayung', 12346),
('CU0007', 'Hendrik Gunawan', 'Jl. Diponegoro No. 707', 081234567899, 'Surabaya', 'Gubeng', 23457),
('CU0008', 'Putri Kusuma', 'Jl. Jendral Sudirman No. 808', 081234567900, 'Bandung', 'Cibeunying', 34568),
('CU0009', 'Budi Hartono', 'Jl. Gatot Subroto No. 909', 081234567901, 'Medan', 'Kota Matsum', 45679),
('CU0010', 'Rina Setiawan', 'Jl. Ahmad Yani No. 1010', 081234567902, 'Yogyakarta', 'Pakualaman', 56780),
('CU0011', 'Dewi Susanti', 'Jl. Pahlawan No. 1111', 081234567903, 'Semarang', 'Banyumanik', 67892),
('CU0012', 'Firman Wijaya', 'Jl. Kartini No. 1212', 081234567904, 'Surakarta', 'Banyuanyar', 78903),
('CU0013', 'Rudi Hidayat', 'Jl. Imam Bonjol No. 1313', 081234567905, 'Palembang', 'Bukit Kecil', 89014),
('CU0014', 'Lina Handayani', 'Jl. Jenderal Ahmad Yani No. 1414', 081234567906, 'Denpasar', 'Denpasar Utara', 90125),
('CU0015', 'Ferryanto Lim', 'Jl. Teuku Umar No. 1515', 081234567907, 'Balikpapan', 'Batu Ampar', 01236),
('CU0016', 'Lukman Hakim', 'Jl. Merdeka No. 1616', 081234567908, 'Jakarta', 'Menteng', 12347),
('CU0017', 'Diana Surya', 'Jl. Asia Afrika No. 1717', 081234567909, 'Bandung', 'Braga', 23458),
('CU0018', 'Rizki Pratama', 'Jl. Raya Kuta No. 1818', 081234567910, 'Denpasar', 'Kuta', 34569),
('CU0019', 'Dewi Lestari', 'Jl. Sudirman No. 1919', 081234567911, 'Surabaya', 'Dukuh Pakis', 45670),
('CU0020', 'Herman Santoso', 'Jl. Diponegoro No. 2020', 081234567912, 'Yogyakarta', 'Demangan', 56781),
('CU0021', 'Rina Cahyani', 'Jl. Jenderal Sudirman No. 2121', 081234567913, 'Semarang', 'Gajah Mungkur', 67893),
('CU0022', 'Eko Susanto', 'Jl. Gajah Mada No. 2222', 081234567914, 'Medan', 'Petisah', 78904),
('CU0023', 'Siti Fatimah', 'Jl. Imam Bonjol No. 2323', 081234567915, 'Jakarta', 'Kebayoran Baru', 89015),
('CU0024', 'Bambang Wijaya', 'Jl. Diponegoro No. 2424', 081234567916, 'Bandung', 'Cicendo', 01237),
('CU0025', 'Rani Putri', 'Jl. Asia Afrika No. 2525', 081234567917, 'Surabaya', 'Gubeng', 12348)
;


create table product (id_product varchar (15), nama_product varchar (50), harga_product float,
qtysisa_product int, kategori_product varchar (15),detailkategori_product varchar (15), image varchar (300)
);

INSERT INTO product (id_product, nama_product, harga_product, qtysisa_product, kategori_product, detailkategori_product, image)
VALUES 
('PD0001', 'COSRX AHA/BHA Clarifying Treatment Toner', 150000, 50, 'skincare', 'toner','COSRX_Toner.jpg'),
('PD0002', 'The Ordinary Niacinamide 10% + Zinc 1% Serum', 250000, 30, 'skincare', 'serum','Ordinary.jpg'),
('PD0003', 'SK-II Facial Treatment Essence', 180000, 40, 'skincare', 'essence','sk-ii.jpg'),
('PD0004', 'CeraVe Moisturizing Cream', 200000, 35, 'skincare', 'moisturizer','CeraVe.jpg'),
('PD0005', 'Biore UV Aqua Rich Watery Essence SPF50+', 120000, 60, 'skincare', 'sunscreen','BioreUV.jpg'),
('PD0006', 'Fenty Beauty Pro Foundation', 350000, 25, 'makeup', 'foundation','Fenty.jpg'),
('PD0007', 'Laneige Layering Cover Cushion', 320000, 20, 'makeup', 'cushion','Laneige.jpg'),
('PD0008', 'NARS Radiant Creamy Concealer', 320000, 30, 'makeup', 'concealer','NARS.jpg'),
('PD0009', 'Laura Mercier Translucent Loose Setting Powder', 450000, 15, 'makeup', 'loose powder','Laura.jpg'),
('PD0010', 'NARS Blush', 350000, 20, 'makeup', 'blush','nars_blush.jpg'),
('PD0011', 'The Body Shop Body Lotion', 150000, 30, 'body care', 'body lotion','Body_Shop.jpg'),
('PD0012', 'St. Ives Gentle Smoothing Body Scrub', 100000, 40, 'body care', 'body scrub','Ives.jpg'),
('PD0013', 'Dove Deeply Nourishing Body Wash', 50000, 50, 'body care', 'body wash','Dove.jpg'),
('PD0014', 'Biore UV Aqua Rich Watery Essence SPF50+', 120000, 25, 'body care', 'sunblock','BioreUV2.jpg'),
('PD0015', 'NIVEA Sun UV Face Sunscreen SPF50', 80000, 30, 'body care', 'sunblock','NIVEA.jpg'),
('PD0016', 'Laneige Water Bank Hydro Essence', 250000, 20, 'skincare', 'essence','Laneige_water.jpg'),
('PD0017', 'Maybelline Fit Me Matte + Poreless Foundation', 120000, 15, 'makeup', 'foundation','Maybelline.jpg'),
('PD0018', 'Vaseline Advanced Repair Body Lotion', 30000, 40, 'body care', 'body lotion','Vaseline.jpg'),
('PD0019', 'The Ordinary Niacinamide 10% + Zinc 1%', 150000, 25, 'skincare', 'serum','OrdinarySerum.jpg'),
('PD0020', 'Sensatia Botanicals Coffee & Cacao Facial Scrub', 85000, 30, 'body care', 'body scrub','Sensatia.jpg'),
('PD0021', 'MAC Studio Fix Powder Plus Foundation', 350000, 10, 'makeup', 'loose powder','MAC.jpg'),
('PD0022', 'Innisfree Green Tea Seed Serum', 180000, 20, 'skincare', 'serum','Innisfree.jpg'),
('PD0023', 'Etude House Dear Darling Water Gel Tint', 50000, 30, 'makeup', 'lipstick','Etude.jpg'),
('PD0024', 'COSRX AHA/BHA Clarifying Treatment Toner', 120000, 20, 'skincare', 'toner','COSRX_Toner.jpg'),
('PD0025', 'Revlon ColorStay Concealer', 90000, 25, 'makeup', 'concealer','Revlon.jpg')
;

create table cart (id_product varchar (10), id_cust varchar(10),qty_detail_cart int, harga int
);

INSERT INTO cart (id_product, id_cust,qty_detail_cart, harga) VALUES
('PD0018', 'CU0021',3,90000),
('PD0025', 'CU0025',1,90000),
('PD0019', 'CU0006',2,300000),
('PD0004', 'CU0004',1,200000),
('PD0018', 'CU0018',2,60000),
('PD0020', 'CU0020',1,85000),
('PD0023', 'CU0023',1,50000),
('PD0009', 'CU0009',1,450000),
('PD0017', 'CU0007',2,240000),
('PD0006', 'CU0013',1,350000),
('PD0002', 'CU0002',2,500000),
('PD0008', 'CU0017',1,320000),
('PD0019', 'CU0010',1,150000),
('PD0021', 'CU0015',2,700000),
('PD0001', 'CU0019',4,600000),
('PD0018', 'CU0024',5,150000),
('PD0001', 'CU0012',2,300000),
('PD0010', 'CU0011',1,350000),
('PD0021', 'CU0022',1,350000),
('PD0009', 'CU0016',1,450000),
('PD0018', 'CU0014',1,30000),
('PD0001', 'CU0015',1,150000),
('PD0025', 'CU0003',2,180000),
('PD0023', 'CU0018',1,50000),
('PD0007', 'CU0005',1,320000)
;

create table pesanan (id_pesanan varchar (10), id_cust varchar (10) references customer, 
jmlh_qty int ,jmlh_harga int,tgl_pesanan date
);

INSERT INTO pesanan (id_pesanan, id_cust, jmlh_qty, jmlh_harga, tgl_pesanan) 
VALUES 
('0001', 'CU0001', 5, 760000, '2024-04-29'),
('0002', 'CU0002', 5, 550000, '2024-04-30'),
('0003', 'CU0003', 4, 420000, '2024-05-01'),
('0004', 'CU0004', 3, 420000, '2024-05-02'),
('0005', 'CU0005', 6, 750000, '2024-05-03'),
('0006', 'CU0006', 2, 360000, '2024-05-04'),
('0007', 'CU0007', 4, 770000, '2024-05-05'),
('0008', 'CU0008', 5, 1460000, '2024-05-06'),
('0009', 'CU0009', 1, 450000, '2024-05-07'),
('0010', 'CU0010', 2, 500000, '2024-05-08'),
('0011', 'CU0011', 3, 480000, '2024-05-09'),
('0012', 'CU0012', 3, 555000, '2024-05-10'),
('0013', 'CU0013', 4, 1070000, '2024-05-11'),
('0014', 'CU0014', 2, 240000, '2024-05-12'),
('0015', 'CU0015', 5, 700000, '2024-05-13');


CREATE TABLE detail_pesanan (id_detail_pesanan varchar (10),id_pesanan varchar(10),id_product varchar(10),
qty_detail int,harga int
);

INSERT INTO detail_pesanan (id_detail_pesanan,id_pesanan, id_product, qty_detail, harga) VALUES
('IDP0001','0001', 'PD0001', 1, 150000),
('IDP0002','0001', 'PD0023', 1, 50000),
('IDP0003','0001', 'PD0018', 1, 30000),
('IDP0004','0001', 'PD0022', 1, 180000),
('IDP0005','0001', 'PD0021', 1, 350000),
('IDP0006','0002', 'PD0001', 2, 300000),
('IDP0007','0002', 'PD0019', 1, 150000),
('IDP0008','0002', 'PD00013', 2, 100000),
('IDP0009','0003', 'PD0019', 1, 150000),
('IDP0010','0003', 'PD0001', 1, 150000),
('IDP0011','0003', 'PD0018', 1, 30000),
('IDP0012','0003', 'PD0025', 1, 90000),
('IDP0013','0004', 'PD0024', 1, 120000),
('IDP0014','0004', 'PD0004', 1, 200000),
('IDP0015','0004', 'PD0012', 1, 100000),
('IDP0016','0005', 'PD0013', 2, 100000),
('IDP0017','0005', 'PD0012', 1, 100000),
('IDP0018','0005', 'PD0006', 1, 350000),
('IDP0019','0005', 'PD0023', 1, 50000),
('IDP0020','0005', 'PD0019', 1, 150000),
('IDP0021','0006', 'PD0009', 2, 360000),
('IDP0022','0007', 'PD0019', 2, 120000),
('IDP0023','0007', 'PD0006', 1, 350000),
('IDP0024','0007', 'PD0017', 1, 120000),
('IDP0025','0008', 'PD0002', 2, 500000),
('IDP0026','0008', 'PD0008', 3, 960000),
('IDP0027','0009', 'PD009', 1, 450000),
('IDP0028','0010', 'PD0021', 1, 350000),
('IDP0029','0010', 'PD0001', 1, 150000),
('IDP0030','0011', 'PD0003', 2, 360000),
('IDP0031','0011', 'PD0005', 1, 120000),
('IDP0032','0012', 'PD0006', 1, 350000),
('IDP0033','0012', 'PD0014', 1, 120000),
('IDP0034','0012', 'PD0020', 1, 85000),
('IDP0035','0013', 'PD0009', 1, 450000),
('IDP0036','0013', 'PD0013', 1, 50000),
('IDP0037','0013', 'PD0016', 1, 250000),
('IDP0038','0013', 'PD0007', 1, 320000),
('IDP0039','0014', 'PD0017', 1, 120000),
('IDP0040','0014', 'PD0024', 1, 120000),
('IDP0041','0015', 'PD0025', 1, 90000),
('IDP0042','0015', 'PD0003', 1, 180000),
('IDP0043','0015', 'PD0015', 1, 80000),
('IDP0044','0015', 'PD0010', 1, 350000)
;
