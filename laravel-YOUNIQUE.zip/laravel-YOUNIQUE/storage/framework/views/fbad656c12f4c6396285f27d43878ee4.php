<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styling (optional) */
        .table-wrapper {
            margin: 20px;
        }
        .form-control {
            margin-right: 10px !important;
        }
        .table-responsive{
            margin: 20px;
            width: auto;
        }
    </style>
</head>
<body>
<div class="table-wrapper">
    <a href="home.html" class="btn btn-primary">Back to Home</a><br><br>
    <h3>Transaction Data</h3>
    <div class="table-responsive">
        <input class="form-control mb-3" id="searchInputTransactions" type="text" placeholder="Search transactions...">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th onclick="sortTable(0, 'transactionTable')">Transaction ID</th>
                    <th onclick="sortTable(1, 'transactionTable')">Date</th>
                    <th onclick="sortTable(2, 'transactionTable')">Customer Name</th>
                    <th onclick="sortTable(3, 'transactionTable')">Amount</th>
                    <th onclick="sortTable(4, 'transactionTable')">Status</th>
                </tr>
            </thead>
            <tbody id="transactionTable">
                <tr>
                    <td>TXN001</td>
                    <td>2024-05-20</td>
                    <td>John Doe</td>
                    <td>$100.00</td>
                    <td>Completed</td>
                </tr>
                <tr>
                    <td>TXN002</td>
                    <td>2024-05-21</td>
                    <td>Jane Smith</td>
                    <td>$200.00</td>
                    <td>Pending</td>
                </tr>
                <!-- More rows as needed -->
            </tbody>
        </table>
    </div>
</div>

<div class="table-wrapper">
    <h3>Product Maintenance</h3>
    <div class="mb-3 isi" style="display: flex;">
        <input class="form-control mr-2" id="productName" type="text" placeholder="Product Name">
        <input class="form-control mr-2" id="brandshoes" type="text" placeholder="Brand">
        <input class="form-control mr-2" id="catagory" type="text" placeholder="Category">
        <input class="form-control mr-2" id="gender" type="text" placeholder="Gender">
        <input class="form-control mr-2" id="color" type="text" placeholder="Color">
        <input class="form-control mr-2" id="price" type="number" placeholder="Price">
        <input class="form-control mr-2" id="image" type="text" placeholder="Link image">
        <button class="btn btn-success" onclick="addProduct()">Add Product</button>
    </div>
</div>

<div class="table-responsive">
    <input class="form-control mb-3" id="searchInputProducts" type="text" placeholder="Search products...">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th onclick="sortTable(0, 'productTable')">Product ID</th>
                <th onclick="sortTable(1, 'productTable')">Product Name</th>
                <th onclick="sortTable(2, 'productTable')">Brand </th>
                <th onclick="sortTable(3, 'productTable')">Category</th>
                <th onclick="sortTable(4, 'productTable')">Gender</th>
                <th onclick="sortTable(5, 'productTable')">Color</th>
                <th onclick="sortTable(6, 'productTable')">Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="productTable">
            <!-- Placeholder for product data -->
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    // Dummy data for initial display
    let products = [
        { id: 'PROD001', name: 'Product 1', brand: 'Brand 1', category: 'Category 1', gender: 'Male', color: 'Blue', price: '$10.00' },
        { id: 'PROD002', name: 'Product 2', brand: 'Brand 2', category: 'Category 2', gender: 'Female', color: 'Red', price: '$20.00' }
        // Add more products here as needed
    ];

    // Display initial product data
    displayProducts(products);

    function displayProducts(products) {
        let tableBody = document.getElementById("productTable");
        tableBody.innerHTML = "";
        products.forEach(product => {
            let row = tableBody.insertRow();
            row.innerHTML = `<td>${product.id}</td>
                             <td>${product.name}</td>
                             <td>${product.brand}</td>
                             <td>${product.category}</td>
                             <td>${product.gender}</td>
                             <td>${product.color}</td>
                             <td>${product.price}</td>
                             <td>
                                 <button class="btn btn-primary btn-sm" onclick="editProduct(this)">Edit</button>
                                 <button class="btn btn-danger btn-sm" onclick="deleteProduct(this)">Delete</button>
                             </td>`;
        });
    }

    function addProduct() {
        let name = document.getElementById("productName").value;
        let brand = document.getElementById("brandshoes").value;
        let category = document.getElementById("catagory").value;
        let gender = document.getElementById("gender").value;
        let color = document.getElementById("color").value;
        let price = document.getElementById("price").value;
        let id = `PROD00${products.length + 1}`;
        products.push({ id, name, brand, category, gender, color, price });
        displayProducts(products);
    }

    function editProduct(button) {
        let row = button.parentNode.parentNode;
        let id = row.cells[0].innerHTML;
        let product = products.find(p => p.id === id);
        if (product) {
            document.getElementById("productName").value = product.name;
            document.getElementById("brandshoes").value = product.brand;
            document.getElementById("catagory").value = product.category;
            document.getElementById("gender").value = product.gender;
            document.getElementById("color").value = product.color;
            document.getElementById("price").value = product.price;
            deleteProduct(button); // remove the current row to add the updated values
        }
    }

    function deleteProduct(button) {
        let row = button.parentNode.parentNode;
        let id = row.cells[0].innerHTML;
        products = products.filter(p => p.id !== id);
        displayProducts(products);
    }

    // Pencarian Produk
    $(document).ready(function(){
        $("#searchInputProducts").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#productTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });

    // Pengurutan
    function sortTable(columnIndex, tableId) {
        var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
        table = document.getElementById(tableId);
        switching = true;
        dir = "asc"; 
        while (switching) {
            switching = false;
            rows = table.rows;
            for (i = 1; i < (rows.length - 1); i++) {
                shouldSwitch = false;
                x = rows[i].getElementsByTagName("TD")[columnIndex];
                y = rows[i + 1].getElementsByTagName("TD")[columnIndex];
                if (dir == "asc") {
                    if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir == "desc") {
                    if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount == 0 && dir == "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
    }
     // Manajemen Produk
     let productId = 3; // Starting from 3 due to dummy data
    function addProduct() {
        let name = document.getElementById("productName").value;
        let price = document.getElementById("productPrice").value;
        if (name && price) {
            let table = document.getElementById("productTable");
            let row = table.insertRow();
            row.innerHTML = `<td>PROD${productId++}</td>
                             <td>${name}</td>
                             <td>$${price}</td>
                             <td>
                                 <button class="btn btn-primary btn-sm" onclick="editProduct(this)">Edit</button>
                                 <button class="btn btn-danger btn-sm" onclick="deleteProduct(this)">Delete</button>
                             </td>`;
            document.getElementById("productName").value = '';
            document.getElementById("productPrice").value = '';
        }
    }

    function editProduct(button) {
        let row = button.parentNode.parentNode;
        let name = row.cells[1].innerHTML;
        let price = row.cells[2].innerHTML.substring(1);
        document.getElementById("productName").value = name;
        document.getElementById("productPrice").value = price;
        deleteProduct(button); // remove the current row to add the updated values
    }

    function deleteProduct(button) {
        let row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
</script>
</body>
</html>
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-YOUNIQUE\resources\views/admin.blade.php ENDPATH**/ ?>